<?php
session_start();

?>
<!DOCTYPE HTML>
<html lang="pl-PL">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Podziekowanie</title>
    <meta name="description" content="Ankieta - Tarczyca." />
    <meta name="keywords" content="ankiety,tarczyca" />
    <link rel="stylesheet" href="CSS-tarczyca.css" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Lato:400,900&amp;subset=latin-ext" rel="stylesheet" />

</head>

<body>

    <a name="gora"></a>

    <div id="container">

        <div id="logo">
            <div id="left">
                <a href="index.php">
                    <img src="logo2.png" alt="logo" />
                </a>
                
            </div>

        </div>

        <div id="content2">
            <img src="dzieki.png" />

        </div>

        <br />
        <br />

        <div id="footer">
            <a href="#gora">Wróć na początek strony :)</a>
        </div>
</body>
</html>