
<?php

    $host = '***.cba.pl';
    $db_user = '***';
    $db_password = '***';
    $db_name = '***';
?>
