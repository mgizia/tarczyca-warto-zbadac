<?php
    //P�e�
	$k_tak = 74/79;
    $k_nie = 27/38;
    $m_tak = 1 - $k_tak;
    $m_nie = 1 - $k_nie;
	
    //�rodowisko �ycia
    $srodo1A_tak = 66/79;
    $srodo1A_nie = 24/38;
    $srodo2A_tak = 1 - $srodo1A_tak;
    $srodo2A_nie = 1 - $srodo1A_nie;
    
    
    //Aktywno�� fizyczna
    $aktywF_tak = 47/79;
    $aktywF_nie = 19/38;
    $aktywT_tak = 1 - $aktywF_tak;
    $aktywT_nie = 1 - $aktywF_nie;

    $dietaT_tak = 41/79;
    $dietaT_nie = 17/38;
    $dietaF_tak = 1 - $dietaT_tak;
    $dietaF_nie = 1 - $dietaT_nie;

    $wrodzinieT_tak = 61/79;
    $wrodzinieT_nie = 23/38;
    $wrodzinieF_tak = 1 - $wrodzinieT_tak;
    $wrodzinieF_nie = 1 - $wrodzinieT_nie;

    $depresjaF_tak = 62/79;
    $depresjaF_nie = 30/38;
    $depresjaT_tak = 1 - $depresjaF_tak;
    $depresjaT_nie = 1 - $depresjaT_nie;


    $otyloscF_tak = 70/79;
    $otyloscF_nie = 33/38;
    $otyloscT_tak = 1 - $otyloscF_tak;
    $otyloscT_nie = 1 - $otyloscT_nie;

    $cukrzycaF_tak = 74/79;
    $cukrzycaF_nie = 36/38;
    $cukrzycaT_tak = 1 - $cukrzycaF_tak;
    $cukrzycaT_nie = 1 - $cukrzycaT_nie;


    $wzrostmasyF_tak = 33/79;
    $wzrostmasyF_nie = 24/38;
    $wzrostmasyT_tak = 1 - $wzrostmasyF_tak;
    $wzrostmasyT_nie = 1 - $wzrostmasyT_nie;


    $oslabienieF_tak = 27/79;
    $oslabienieF_nie = 30/38;
    $oslabienieT_tak = 1 - $oslabienieF_tak;
    $oslabienieT_nie = 1 - $oslabienieT_nie;

    $sennoscF_tak = 17/79;
    $sennoscF_nie = 20/38;
    $sennoscT_tak = 1 - $sennoscF_tak;
    $sennoscT_nie = 1 - $sennoscT_nie;

   
    $suchaskoraF_tak = 34/79;
    $suchaskoraF_nie = 33/38;
    $suchaskoraT_tak = 1 - $suchaskoraF_tak;
    $suchaskoraT_nie = 1 - $suchaskoraT_nie;


    $pamiecF_tak = 34/79;
    $pamiecF_nie = 32/38;
    $pamiecT_tak = 1 - $pamiecF_tak;
    $pamiecT_nie = 1 - $pamiecT_nie;


    $zmeczenieF_tak = 30/79;
    $zmeczenieF_nie = 27/38;
    $zmeczenieT_tak = 1 - $zmeczenieF_tak;
    $zmeczenieT_nie = 1 - $zmeczenieT_nie;

    $bladaskoraF_tak = 54/79;
    $bladaskoraF_nie = 35/38;
    $bladaskoraT_tak = 1 - $bladaskoraF_tak;
    $bladaskoraT_nie = 1 - $bladaskoraT_nie;

    $kolataniesercaF_tak = 61/79;
    $kolataniesercaF_nie = 29/38;
    $kolataniesercaT_tak = 1 - $kolataniesercaF_tak;
    $kolataniesercaT_nie = 1 - $kolataniesercaT_nie;

    $szyjaF_tak = 65/79;
    $szyjaF_nie = 36/38;
    $szyjaT_tak = 1 - $szyjaF_tak;
    $szyjaT_nie = 1 - $szyjaT_nie;
 //v
    $miesiaczkaF_tak = 50/79;
    $miesiaczkaF_nie = 35/38;
    $miesiaczkaT_tak = 1 - $miesiaczkaF_tak;
    $miesiaczkaT_nie = 1 - $miesiaczkaT_nie;

    $ciazaF_tak = 72/79;
    $ciazaF_nie = 37/38;
    $ciazaT_tak = 1 - $ciazaF_tak;
    $ciazaT_nie = 1 - $ciazaT_nie;


?>
